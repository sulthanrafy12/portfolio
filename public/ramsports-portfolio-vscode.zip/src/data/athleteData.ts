import { AthleteProfile, PerformanceStats, TournamentRecord, MediaItem, SponsorshipTier, SocialStat } from '../types';

export const INITIAL_ATHLETE_PROFILE: AthleteProfile = {
  name: 'Ravy Sultan',
  tagline: 'Elite Competitive Pickleball Athlete & Ramsports Ambassador Candidate',
  discipline: "Competitive Pickleball (Men's Singles & Men's Doubles)",
  duprSingles: 4.98,
  duprDoubles: 5.14,
  location: 'DKI Jakarta & Jabodetabek, Indonesia',
  email: 'ravysultan9@gmail.com',
  phone: '+62 812-8899-2345',
  whatsappNumber: '6281288992345',
  instagram: '@ravysultan',
  tiktok: '@ravysultan.pickleball',
  paddleBrandCurrent: 'Kamito Pro (Seeking Ramsports Pro Upgrade)',
  targetSponsor: 'Ramsports | Global Pickleball Brand',
  summary: 'Atlet Pickleball kompetitif dengan rekam jejak 7x podium kejuaraan bergengsi di Jakarta & nasional (Juara 1 Kadispora, Juara 2 Jakarta Championship, ITB Open, Kadispora Doubles, UNJ Singles, Juara 3 UI & Jabodetabek). Siap membawa nama dan teknologi gear Ramsports ke puncak podium 2026/2027.',
};

export const INITIAL_PERFORMANCE_STATS: PerformanceStats = {
  matchesPlayed: 52,
  matchesWon: 44,
  winRate: 84.6,
  podiumsTotal: 7,
  goldCount: 1,
  silverCount: 4,
  bronzeCount: 2,
  thirdShotDropPct: 88.4,
  speedUpConversionPct: 91.2,
  dinkRallyEndurancePct: 94.0,
  unforcedErrorsAvg: 3.4,
  currentStreak: 6,
  avgSmashSpeedKmh: 98.5,
  tournamentsCompeted: 9,
  lastSyncTime: '2026-09-30 08:35:12 WIB',
};

export const TOURNAMENT_RECORDS: TournamentRecord[] = [
  {
    id: 't-1',
    title: 'Kejuaraan Kadispora Cup DKI Jakarta',
    achievement: 'Juara 1 (Champion)',
    tier: 'gold',
    category: "Open Championship",
    location: 'Jakarta',
    year: '2025/2026',
    fileName: 'sertifjuara1kadispora.jpeg',
    notes: 'Sertifikat resmi Juara 1 Turnamen Kadispora. Performa tak terkalahkan sepanjang babak penyisihan hingga final.',
    statsHighlight: 'Unbeaten run (6-0), Final score 11-8, 11-6'
  },
  {
    id: 't-2',
    title: 'Jakarta Pickleball Championship',
    achievement: 'Juara 2 (Silver Medalist)',
    tier: 'silver',
    category: "Men's Singles",
    location: 'Jakarta',
    year: '2025',
    fileName: 'juara2jakartapickleballchampionship.jpeg',
    notes: 'Kompetisi terakbar se-DKI Jakarta. Perebutan medali perak dengan intensitas rally tinggi dan match point dramatis.',
    statsHighlight: 'Semifinal clutch 12-10, 89% smash accuracy'
  },
  {
    id: 't-3',
    title: 'ITB Open Pickleball Championship',
    achievement: "Juara 2 Men's Doubles",
    tier: 'silver',
    category: "Men's Doubles",
    location: 'Bandung / ITB',
    year: '2025',
    fileName: 'juara2mensdoubleitb.jpg',
    notes: 'Kategori ganda putra antar-universitas & terbuka. Koordinasi court coverage dan dinking battle yang solid.',
    statsHighlight: 'Win-rate ganda 83%, kitchen attack conversion 92%'
  },
  {
    id: 't-4',
    title: "Kadispora Cup Men's Doubles",
    achievement: "Juara 2 Men's Doubles",
    tier: 'silver',
    category: "Men's Doubles",
    location: 'Jakarta',
    year: '2025',
    fileName: 'juara2mensdoublekadispora.jpg',
    notes: 'Medali perak ganda putra tingkat Dispora. Pertahanan kitchen line kokoh dan counter-attack tajam.',
    statsHighlight: 'Avg unforced error < 3 per set'
  },
  {
    id: 't-5',
    title: "UNJ Open National Pickleball Tournament",
    achievement: "Juara 2 Men's Singles",
    tier: 'silver',
    category: "Men's Singles",
    location: 'Jakarta / UNJ',
    year: '2025',
    fileName: 'juara2menssingleunj.jpg',
    notes: 'Podium perak nomor tunggal putra di arena olahraga Universitas Negeri Jakarta.',
    statsHighlight: 'Akurasi third shot drop 91%'
  },
  {
    id: 't-6',
    title: 'Kejuaraan Pickleball Terbuka Jabodetabek',
    achievement: 'Juara 3 (Bronze Medalist)',
    tier: 'bronze',
    category: "Open Championship",
    location: 'Jabodetabek',
    year: '2024/2025',
    fileName: 'juara3jabodetabek.jpeg',
    notes: 'Peringkat 3 besar dari 48 pasang/atlet peserta regional Jabodetabek.',
    statsHighlight: 'Comeback kemenangan di perebutan Bronze 15-13'
  },
  {
    id: 't-7',
    title: "Universitas Indonesia (UI) Open Championship",
    achievement: "Juara 3 Men's Doubles",
    tier: 'bronze',
    category: "Men's Doubles",
    location: 'Depok / Kampus UI',
    year: '2024',
    fileName: 'juara3mensdoubleUI.jpg',
    notes: 'Podium perunggu ganda putra dalam turnamen bergengsi Universitas Indonesia.',
    statsHighlight: 'Dominasi servis ace & rally dink panjang'
  }
];

export const MEDIA_COLLECTION: MediaItem[] = [
  {
    fileName: 'fotoprofil.jpg',
    title: 'Official Athlete Headshot & Portrait',
    category: 'profile',
    description: 'Foto profil resmi Ravy Sultan untuk promosi media atlet, sponsorship kit, dan pengumuman roster atlet.',
    highResStockFallback: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
    fallbackGradient: 'from-zinc-900 to-black'
  },
  {
    fileName: 'foto in game.jpg',
    title: 'Court Action & High-Speed Play',
    category: 'action',
    description: 'Aksi dinamis saat bertanding di lapangan: smash forehand, transisi dink ke kitchen zone, dan refleks cepat.',
    highResStockFallback: 'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?auto=format&fit=crop&w=1200&q=80',
    fallbackGradient: 'from-amber-950 to-zinc-950'
  },
  {
    fileName: 'fotomenggunakanmedali.jpg',
    title: 'Podium Glory with Medals',
    category: 'trophy',
    description: 'Foto perayaan kemenangan dengan medali kejuaraan terkalung di leher setelah pertandingan final.',
    highResStockFallback: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=800&q=80',
    fallbackGradient: 'from-yellow-950 to-zinc-900'
  },
  {
    fileName: 'fotobeberapamedali.jpg',
    title: 'Medal Collection & Trophy Showcase',
    category: 'trophy',
    description: 'Koleksi medali emas, perak, dan perunggu dari berbagai turnamen resmi regional dan nasional.',
    highResStockFallback: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80',
    fallbackGradient: 'from-neutral-900 to-black'
  },
  {
    fileName: 'fotopaddlekamito.png',
    title: 'Current Equipment Setup (Ready for Ramsports)',
    category: 'gear',
    description: 'Foto paddle Kamito yang digunakan sebelumnya. Siap beralih dan di-upgrade penuh ke line-up paddle Ramsports.',
    highResStockFallback: 'https://images.unsplash.com/photo-1599474924187-334a4ae5bd3c?auto=format&fit=crop&w=800&q=80',
    fallbackGradient: 'from-lime-950 to-neutral-900'
  },
  {
    fileName: 'sertifjuara1kadispora.jpeg',
    title: 'Sertifikat Juara 1 Kadispora',
    category: 'trophy',
    description: 'Dokumen bukti otentik gelar Juara 1 Turnamen Kadispora DKI Jakarta.',
    highResStockFallback: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-amber-900 to-black'
  },
  {
    fileName: 'juara2jakartapickleballchampionship.jpeg',
    title: 'Dokumentasi Juara 2 Jakarta Championship',
    category: 'trophy',
    description: 'Momen penganugerahan medali perak Jakarta Pickleball Championship.',
    highResStockFallback: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-slate-900 to-zinc-900'
  },
  {
    fileName: 'juara2mensdoubleitb.jpg',
    title: 'Dokumentasi Juara 2 ITB Open Men Doubles',
    category: 'trophy',
    description: 'Podium ganda putra bersama partner di gelaran ITB Open Bandung.',
    highResStockFallback: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-blue-950 to-neutral-900'
  },
  {
    fileName: 'juara2mensdoublekadispora.jpg',
    title: 'Dokumentasi Juara 2 Men Doubles Kadispora',
    category: 'trophy',
    description: 'Serah terima medali perak ganda putra Kejuaraan Kadispora.',
    highResStockFallback: 'https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-zinc-900 to-neutral-950'
  },
  {
    fileName: 'juara2menssingleunj.jpg',
    title: 'Dokumentasi Juara 2 UNJ Open Singles',
    category: 'trophy',
    description: 'Pencapaian podium nomor tunggal putra di UNJ Open.',
    highResStockFallback: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-emerald-950 to-neutral-900'
  },
  {
    fileName: 'juara3jabodetabek.jpeg',
    title: 'Dokumentasi Juara 3 Turnamen Jabodetabek',
    category: 'trophy',
    description: 'Trofi dan medali perunggu kejuaraan regional se-Jabodetabek.',
    highResStockFallback: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-amber-950 to-neutral-900'
  },
  {
    fileName: 'juara3mensdoubleUI.jpg',
    title: 'Dokumentasi Juara 3 UI Open Men Doubles',
    category: 'trophy',
    description: 'Prestasi podium ketiga ganda putra turnamen Universitas Indonesia.',
    highResStockFallback: 'https://images.unsplash.com/photo-1577471488278-16eec37ffcc2?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-yellow-950 to-stone-900'
  },
  {
    fileName: 'my instagram.png',
    title: 'Instagram Reach & Audience Analytics',
    category: 'social',
    description: 'Metrik audiens Instagram: impresi bulanan, demografi pemain pickleball Jabodetabek, dan engagement rate 8.4%.',
    highResStockFallback: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-fuchsia-950 to-purple-950'
  },
  {
    fileName: 'mytiktok.png',
    title: 'TikTok Viral Reels & Pickleball Tutorials',
    category: 'social',
    description: 'Insight konten video pendek pickleball di TikTok dengan ribuan views pada tips dinking & gameplay highlights.',
    highResStockFallback: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?auto=format&fit=crop&w=900&q=80',
    fallbackGradient: 'from-cyan-950 to-slate-900'
  },
  {
    fileName: 'videosatu.mp4',
    title: 'Match Highlights & Reel Gameplay',
    category: 'video',
    description: 'Video kompilasi cuplikan pertandingan real-game: fast-hands kitchen exchange, ATP shot, dan winning points.',
    highResStockFallback: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80',
    fallbackGradient: 'from-zinc-900 via-neutral-900 to-black'
  }
];

export const SOCIAL_STATS: SocialStat[] = [
  {
    platform: 'Instagram',
    handle: '@ravysultan',
    followers: '4.8K+',
    monthlyReach: '42.5K+',
    engagementRate: '8.4%',
    primaryAudience: 'Pickleball Players & Sports Enthusiasts (18-38 yo)',
    fileName: 'my instagram.png'
  },
  {
    platform: 'TikTok',
    handle: '@ravysultan.pickleball',
    followers: '9.2K+',
    monthlyReach: '115.0K+',
    engagementRate: '11.2%',
    primaryAudience: 'Active Racquet Sport Players & Gear Buyers',
    fileName: 'mytiktok.png'
  }
];

export const SPONSORSHIP_TIERS: SponsorshipTier[] = [
  {
    id: 'tier-gear',
    name: 'Official Equipment & Paddle Partner',
    subtitle: 'Entry Synergy Tier',
    recommended: false,
    investmentTier: 'Peralatan & Gear Support',
    synergyHighlight: 'Eksklusivitas penggunaan paddle Ramsports di seluruh sesi latihan, sparring, dan turnamen resmi.',
    features: [
      'Penyediaan 3-4 unit Official Ramsports Pro Paddles (Raw Carbon Fiber Series)',
      'Aksesoris resmi (Ramsports Grip, Balls, Overgrip, Cover)',
      'Jersey & Apparel kit dengan logo Ramsports tercetak jelas',
      'Uji coba prototipe paddle & feedback teknis langsung dari atlet'
    ],
    deliverables: [
      'Tag @ramsportspickleball di setiap postingan latihan & tanding',
      '1x video review spesifikasi paddle Ramsports per bulan',
      'Logo Ramsports terpasang pada paddle sleeve & match bag'
    ]
  },
  {
    id: 'tier-pro',
    name: 'Tournament & Travel Title Partner',
    subtitle: 'Most Recommended Partnership',
    recommended: true,
    investmentTier: 'Tournament Support + Monthly Stipend',
    synergyHighlight: 'Eksposur brand Ramsports di setiap podium kejuaraan dan siaran live streaming turnamen nasional.',
    features: [
      'Semua benefit dari Official Equipment Partner',
      'Dukungan biaya pendaftaran turnamen resmi tingkat regional/nasional (7-10 turnamen)',
      'Branded Jersey Ramsports Custom dengan patch utama di dada dan lengan',
      'Banner display / product display booth di turnamen yang diikuti (jika diizinkan panitia)'
    ],
    deliverables: [
      'Minimum 2x konten reels/TikTok dedicated unboxing & playtest gear Ramsports per bulan',
      'Penyebutan nama "Ramsports" dalam interview pasca-pertandingan & podium speech',
      'Foto podium resmi dengan paddle & jersey Ramsports terunggah di semua channel',
      'Hak penggunaan foto & klip atlet dalam iklan digital Ramsports'
    ]
  },
  {
    id: 'tier-ambassador',
    name: 'Signature Brand Ambassador',
    subtitle: 'Strategic Brand Synergy',
    recommended: false,
    investmentTier: 'Annual Full Endorsement & Co-Branding',
    synergyHighlight: 'Kemitraan strategis jangka panjang untuk penetrasi pasar Pickleball Indonesia yang sedang meledak.',
    features: [
      'Semua fasilitas Pro Tournament Partner',
      'Peluang kolaborasi Signature Edition Paddle (Ravy Sultan x Ramsports Pro Series)',
      'Coaching clinic & exhibition match bersama komunitas pickleball Jabodetabek atas nama Ramsports',
      'Representasi brand di event expo olahraga & gathering komunitas resmi'
    ],
    deliverables: [
      'Eksklusivitas 100% kategori pickleball gear & apparel',
      '4x konten bulanan high-production (Reels + TikTok + YouTube shorts)',
      'Kehadiran pada event brand peluncuran produk baru Ramsports di Indonesia',
      'Rekomendasi langsung dan referral link diskon bagi audiens pembeli produk Ramsports'
    ]
  }
];

export const RAMSPORTS_BRAND_INFO = {
  name: 'Ramsports',
  tagline: 'Global Pickleball Brand',
  slogan: 'Trusted by Pros. Built to Compete.',
  bio: 'Pickleball Paddles & Gear. Trusted by Pros. Built to compete. Free Shipping $50+ USCA.',
  website: 'ramsports.com',
  instagram: '@ramsportspickleball',
  accentColor: '#D4FF00',
  secondaryColor: '#0B0E14'
};

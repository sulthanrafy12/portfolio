import React from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Trophy, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  ExternalLink,
  Mail,
  Phone
} from 'lucide-react';
import { INITIAL_ATHLETE_PROFILE, TOURNAMENT_RECORDS, SPONSORSHIP_TIERS, RAMSPORTS_BRAND_INFO } from '../data/athleteData';
import { PerformanceStats } from '../types';

interface ProposalDeckModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: PerformanceStats;
}

export const ProposalDeckModal: React.FC<ProposalDeckModalProps> = ({
  isOpen,
  onClose,
  stats,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl bg-[#0E121A] border border-white/20 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        
        {/* Modal Controls Toolbar */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/60 print:hidden">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D4FF00]" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              OFFICIAL SPONSORSHIP PROPOSAL DECK · RAMSPORTS x {INITIAL_ATHLETE_PROFILE.name.toUpperCase()}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Simpan PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Deck Body */}
        <div className="p-8 sm:p-10 overflow-y-auto space-y-8 bg-[#0B0E14] text-slate-100 print:bg-white print:text-black">
          
          {/* Deck Header */}
          <div className="border-b border-white/10 print:border-black/20 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-full bg-[#D4FF00] flex items-center justify-center">
                  <span className="font-black text-black text-base">R</span>
                </div>
                <span className="font-extrabold text-sm tracking-widest text-[#D4FF00] uppercase">
                  RAMSPORTS GLOBAL PARTNERSHIP INITIATIVE
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black font-heading text-white print:text-black">
                PROPOSAL KEMITRAAN ATLET RESMI
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 print:text-gray-600 mt-1">
                Kandidat Brand Ambassador & Pro Tour Athlete 2026/2027
              </p>
            </div>

            <div className="text-right sm:border-l sm:border-white/10 print:border-black/20 sm:pl-6 text-xs text-slate-400 print:text-gray-600">
              <span className="block font-semibold text-white print:text-black">{INITIAL_ATHLETE_PROFILE.name}</span>
              <span>DUPR Rating: {INITIAL_ATHLETE_PROFILE.duprDoubles} (MD) / {INITIAL_ATHLETE_PROFILE.duprSingles} (MS)</span>
              <span className="block text-emerald-400 font-bold mt-0.5">Win Rate: {stats.winRate}%</span>
            </div>
          </div>

          {/* Section 1: Executive Summary */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#D4FF00] print:text-black mb-2">
              1. RINGKASAN EKSEKUTIF
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 print:text-gray-800 leading-relaxed">
              Industri olahraga Pickleball di Indonesia dan kawasan Asia Tenggara sedang mengalami lonjakan eksponensial. Ramsports sebagai brand global terdepan dengan moto <em>"{RAMSPORTS_BRAND_INFO.slogan}"</em> memiliki momentum emas untuk mendominasi pasar Indonesia. Kolaborasi dengan atlet kompetitif <strong className="text-white print:text-black">Ravy Sultan</strong> menjamin kehadiran brand di panggung podium, interaksi komunitas, dan pembuktian performa nyata produk paddle Ramsports di tangan sang juara.
            </p>
          </div>

          {/* Section 2: Key Podium Finishes */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#D4FF00] print:text-black mb-3">
              2. REKAM JEJAK PODIUM TURNAMEN RESMI (7 GELAR)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {TOURNAMENT_RECORDS.map((tour) => (
                <div key={tour.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 print:border-gray-300">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white print:text-black">{tour.achievement}</span>
                    <span className="text-[10px] text-slate-400">{tour.year}</span>
                  </div>
                  <div className="text-slate-300 print:text-gray-700 font-medium">{tour.title}</div>
                  <div className="text-[10px] font-mono text-[#D4FF00] print:text-black mt-1">
                    Bukti File: {tour.fileName}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 3: Value Proposition */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#D4FF00] print:text-black mb-3">
              3. BENEFIT STRATEGIS BAGI RAMSPORTS
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 print:border-gray-300">
                <span className="font-bold text-[#D4FF00] print:text-black block text-sm mb-1">Brand Authority</span>
                <p className="text-slate-300 print:text-gray-700">
                  Memvalidasi bahwa paddle Ramsports digunakan oleh atlet peringkat atas untuk memenangkan gelar juara nyata.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 print:border-gray-300">
                <span className="font-bold text-white print:text-black block text-sm mb-1">Digital Reach</span>
                <p className="text-slate-300 print:text-gray-700">
                  Potensi 150.000+ impresi gabungan turnamen dan media sosial (Instagram + TikTok) dengan target pembeli perlengkapan olahraga.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 print:border-gray-300">
                <span className="font-bold text-emerald-400 print:text-black block text-sm mb-1">Community Growth</span>
                <p className="text-slate-300 print:text-gray-700">
                  Akses langsung ke komunitas pickleball aktif Jabodetabek melalui sesi clinic, test paddle, dan turnamen terbuka.
                </p>
              </div>
            </div>
          </div>

          {/* Section 4: Contact Action */}
          <div className="pt-6 border-t border-white/10 print:border-black/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div className="text-slate-400 print:text-gray-600">
              <span>Email: <strong className="text-white print:text-black">{INITIAL_ATHLETE_PROFILE.email}</strong></span>
              <span className="mx-2">·</span>
              <span>WhatsApp: <strong className="text-white print:text-black">{INITIAL_ATHLETE_PROFILE.phone}</strong></span>
            </div>

            <div className="print:hidden">
              <a
                href={`https://wa.me/${INITIAL_ATHLETE_PROFILE.whatsappNumber}?text=Halo%20Ravy,%20kami%20telah%20meninjau%20Proposal%20Deck%20Ramsports%20dan%20ingin%20jadwalkan%20diskusi.`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-xl bg-[#D4FF00] hover:bg-[#c2e800] text-black font-extrabold uppercase tracking-wider"
              >
                Inisiasi Kemitraan via WhatsApp
              </a>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  TrendingUp, 
  Flame, 
  ShieldCheck, 
  Zap, 
  Award,
  DollarSign,
  Calculator,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { SPONSORSHIP_TIERS, RAMSPORTS_BRAND_INFO, INITIAL_ATHLETE_PROFILE } from '../data/athleteData';
import { resolveMediaUrl } from '../utils/mediaStorage';

interface RamsportSynergyProps {
  onOpenDeckModal: () => void;
  onOpenMediaModal: () => void;
}

export const RamsportSynergy: React.FC<RamsportSynergyProps> = ({
  onOpenDeckModal,
  onOpenMediaModal,
}) => {
  const [selectedTierId, setSelectedTierId] = useState<string>('tier-pro');

  // Interactive ROI Calculator State
  const [tournamentsCount, setTournamentsCount] = useState<number>(8);
  const [socialFrequency, setSocialFrequency] = useState<number>(4); // posts per month

  // Projected metrics calculation
  const liveAudiencePerTour = 1200;
  const directLiveImpressions = tournamentsCount * liveAudiencePerTour;
  const socialImpressionsYear = socialFrequency * 12 * 8500;
  const totalProjectedImpressions = directLiveImpressions + socialImpressionsYear;
  const estimatedMediaValueIdr = (totalProjectedImpressions * 180).toLocaleString('id-ID');

  const paddleOldUrl = resolveMediaUrl('fotopaddlekamito.png');

  return (
    <section id="synergy" className="py-20 bg-[#0E121A] text-slate-100 relative border-t border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Brand Synergy Headline */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#D4FF00]/10 border border-[#D4FF00]/30 text-[#D4FF00] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>PROPOSAL SPONSORSHIP RESMI · TARGET BRAND</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black font-heading tracking-tight text-white uppercase">
            SINERGI PRESTASI BERSAMA <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4FF00] to-lime-300">
              RAMSPORTS GLOBAL
            </span>
          </h2>

          <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed">
            Mewujudkan moto <strong className="text-white">"{RAMSPORTS_BRAND_INFO.slogan}"</strong> melalui atlet berkarakter juara di Indonesia. Mengonversi reputasi podium menjadi daya beli produk paddle dan gear Ramsports.
          </p>
        </div>

        {/* Paddle Upgrade & Transition Feature (fotopaddlekamito.png transition) */}
        <div className="mt-14 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-white/[0.04] to-black/60 border border-white/10 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left explanation */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded bg-white/10 text-xs font-bold text-[#D4FF00]">
                  EQUIPMENT UPGRADE SPOTLIGHT
                </span>
                <span className="text-xs text-slate-400">
                  File: <code className="text-slate-300 font-mono">fotopaddlekamito.png</code>
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
                Transisi Gear: Siap Menjadi Wajah Resmi Paddle Ramsports
              </h3>

              <p className="text-sm text-slate-300 leading-relaxed">
                Sebelumnya berkompetisi dengan paddle terdahulu (<strong className="text-slate-200">Kamito Pro</strong>). Dengan rating DUPR 5.14 dan permainan tempo tinggi, atlet membutuhkan teknologi <strong className="text-[#D4FF00]">Toray T700 Raw Carbon Fiber & Thermoformed Edge</strong> khas paddle Ramsports untuk memaksimalkan kontrol spin serta smash explosive di kejuaraan 2026/2027.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-xs text-slate-400 block font-medium">Sweet Spot Control</span>
                  <span className="text-lg font-bold text-[#D4FF00]">+25% Precision</span>
                </div>
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-xs text-slate-400 block font-medium">Spin RPM Velocity</span>
                  <span className="text-lg font-bold text-white">2,150+ RPM</span>
                </div>
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-xs text-slate-400 block font-medium">Turnamen Exposure</span>
                  <span className="text-lg font-bold text-emerald-400">100% Branded</span>
                </div>
              </div>
            </div>

            {/* Right Paddle Visual Comparison */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div className="relative w-full max-w-sm rounded-2xl overflow-hidden bg-black/80 border border-white/10 p-4">
                <div className="flex items-center justify-between text-xs pb-3 border-b border-white/10">
                  <span className="text-slate-400">Previous: Kamito</span>
                  <span className="text-[#D4FF00] font-bold">&rarr; Upgrade: Ramsports</span>
                </div>

                <div className="relative aspect-square w-full mt-3 rounded-xl overflow-hidden bg-zinc-950 flex items-center justify-center group">
                  <img
                    src={paddleOldUrl}
                    alt="Current Paddle Setup"
                    className="w-4/5 h-4/5 object-contain transition-transform group-hover:scale-105"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1599474924187-334a4ae5bd3c?auto=format&fit=crop&w=800&q=80';
                    }}
                  />
                  <div className="absolute bottom-2 left-2 right-2 px-3 py-1.5 rounded-lg bg-black/80 backdrop-blur-md border border-white/10 text-[11px] text-slate-300 flex items-center justify-between">
                    <span className="truncate">fotopaddlekamito.png</span>
                    <span className="text-[#D4FF00] font-bold text-[10px]">CURRENT</span>
                  </div>
                </div>

                <div className="mt-3 text-center">
                  <button
                    onClick={onOpenMediaModal}
                    className="text-[11px] text-slate-400 hover:text-[#D4FF00] transition-colors"
                  >
                    Ganti dengan file paddle asli Anda &rarr;
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Interactive Sponsorship ROI Calculator for Potential Partners */}
        <div className="mt-14 p-6 sm:p-8 rounded-3xl bg-black/50 border border-white/10">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-[#D4FF00] uppercase mb-1">
                <Calculator className="w-4 h-4" />
                <span>Simulasi Return On Investment (ROI) Kemitraan</span>
              </div>
              <h3 className="text-2xl font-black font-heading text-white">
                KALKULATOR ESTIMASI EKSPOSUR BRAND RAMSPORTS
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Kalkulasikan proyeksi jangkauan audiens langsung di turnamen dan audiens digital melalui konten atlet.
              </p>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-400 block">Estimasi Nilai Media (EMV)</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-[#D4FF00] font-heading">
                Rp {estimatedMediaValueIdr}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
            
            {/* Slider 1: Tournaments */}
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-2">
                <span className="font-semibold">Jumlah Turnamen Resmi yang Diikuti:</span>
                <span className="text-[#D4FF00] font-extrabold text-sm font-mono">{tournamentsCount} Turnamen</span>
              </div>
              <input
                type="range"
                min="4"
                max="16"
                step="1"
                value={tournamentsCount}
                onChange={(e) => setTournamentsCount(Number(e.target.value))}
                className="w-full accent-[#D4FF00] cursor-pointer h-2 bg-white/10 rounded-lg"
              />
              <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                <span>4 Turnamen (DKI)</span>
                <span>16 Turnamen (National Tour)</span>
              </div>
            </div>

            {/* Slider 2: Social Posts */}
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-2">
                <span className="font-semibold">Intensitas Konten Promosi Bulanan (Reels/TikTok):</span>
                <span className="text-[#D4FF00] font-extrabold text-sm font-mono">{socialFrequency} Konten / Bulan</span>
              </div>
              <input
                type="range"
                min="2"
                max="10"
                step="1"
                value={socialFrequency}
                onChange={(e) => setSocialFrequency(Number(e.target.value))}
                className="w-full accent-[#D4FF00] cursor-pointer h-2 bg-white/10 rounded-lg"
              />
              <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                <span>2 Konten (Review & Play)</span>
                <span>10 Konten (High Frequency)</span>
              </div>
            </div>

          </div>

          {/* Calculator Output Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-white/5">
            <div className="p-3 rounded-xl bg-white/[0.02]">
              <span className="text-[11px] text-slate-400 block">Jangkauan Langsung Court</span>
              <span className="text-xl font-bold text-white font-heading">
                {directLiveImpressions.toLocaleString('id-ID')}+
              </span>
              <span className="text-[10px] text-slate-500 block">Penonton & peserta turnamen</span>
            </div>

            <div className="p-3 rounded-xl bg-white/[0.02]">
              <span className="text-[11px] text-slate-400 block">Jangkauan Digital Tahunan</span>
              <span className="text-xl font-bold text-white font-heading">
                {socialImpressionsYear.toLocaleString('id-ID')}+
              </span>
              <span className="text-[10px] text-slate-500 block">Instagram & TikTok views</span>
            </div>

            <div className="p-3 rounded-xl bg-white/[0.02]">
              <span className="text-[11px] text-slate-400 block">Total Impresi Terakumulasi</span>
              <span className="text-xl font-bold text-[#D4FF00] font-heading">
                {totalProjectedImpressions.toLocaleString('id-ID')}+
              </span>
              <span className="text-[10px] text-slate-500 block">Exposure brand Ramsports</span>
            </div>

            <div className="p-3 rounded-xl bg-white/[0.02]">
              <span className="text-[11px] text-slate-400 block">Efisiensi Biaya (vs Ads)</span>
              <span className="text-xl font-bold text-emerald-400 font-heading">
                68% Lebih Hemat
              </span>
              <span className="text-[10px] text-slate-500 block">Kredibilitas atlet nyata</span>
            </div>
          </div>
        </div>

        {/* Sponsorship Packages Tier Cards */}
        <div className="mt-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl sm:text-3xl font-extrabold font-heading text-white">
              PILIHAN PAKET KEMITRAAN & SPONSORSHIP
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Fleksibel disesuaikan dengan target objektif marketing tim Ramsports Pickleball.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {SPONSORSHIP_TIERS.map((tier) => {
              const isSelected = selectedTierId === tier.id;
              const isRecommended = tier.recommended;

              return (
                <div
                  key={tier.id}
                  onClick={() => setSelectedTierId(tier.id)}
                  className={`relative cursor-pointer rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 ${
                    isRecommended
                      ? 'bg-gradient-to-b from-[#D4FF00]/10 via-[#0B0E14] to-[#0B0E14] border-2 border-[#D4FF00] shadow-2xl shadow-[#D4FF00]/10 -translate-y-2'
                      : 'bg-white/[0.02] border border-white/10 hover:border-white/20'
                  }`}
                >
                  {isRecommended && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[#D4FF00] text-black text-[11px] font-extrabold uppercase tracking-wider shadow-md">
                      PILIHAN TERBAIK UNTUK BRAND
                    </div>
                  )}

                  <div>
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      {tier.subtitle}
                    </div>
                    <h4 className="text-xl font-bold font-heading text-white mt-1">
                      {tier.name}
                    </h4>

                    <div className="mt-4 pb-4 border-b border-white/10">
                      <span className="text-xs text-slate-400 block font-medium">Bentuk Komitmen:</span>
                      <span className="text-sm font-bold text-[#D4FF00]">
                        {tier.investmentTier}
                      </span>
                    </div>

                    {/* Synergy Highlight Quote */}
                    <div className="mt-4 p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs text-slate-300 italic">
                      "{tier.synergyHighlight}"
                    </div>

                    {/* Features list */}
                    <div className="mt-6 space-y-2.5">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                        Fasilitas & Dukungan:
                      </span>
                      {tier.features.map((feat, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                          <CheckCircle2 className="w-4 h-4 text-[#D4FF00] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>

                    {/* Deliverables */}
                    <div className="mt-6 space-y-2 pt-4 border-t border-white/5">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                        Kewajiban & Output Atlet:
                      </span>
                      {tier.deliverables.map((deliv, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-400">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#D4FF00] mt-1.5 shrink-0" />
                          <span>{deliv}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-8 pt-4 border-t border-white/10">
                    <a
                      href={`https://wa.me/${INITIAL_ATHLETE_PROFILE.whatsappNumber}?text=Halo%20Ravy%20Sultan,%20kami%20dari%20tim%20Ramsports%20ingin%20berdiskusi%20mengenai%20paket%20${encodeURIComponent(tier.name)}.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`w-full py-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${
                        isRecommended
                          ? 'bg-[#D4FF00] text-black hover:bg-[#c2e800] shadow-lg shadow-[#D4FF00]/20'
                          : 'bg-white/10 text-white hover:bg-white/20'
                      }`}
                    >
                      <span>Pilih & Diskusikan</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </a>
                  </div>

                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Pitch Summary CTA */}
        <div className="mt-14 text-center">
          <button
            onClick={onOpenDeckModal}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#D4FF00] hover:underline"
          >
            <span>Butuh proposal lengkap dalam format dokumen / PDF siap cetak? Buka ringkasan proposal &rarr;</span>
          </button>
        </div>

      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  CheckCircle2, 
  Copy, 
  Download, 
  FileText, 
  Clock, 
  Sparkles,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { INITIAL_ATHLETE_PROFILE } from '../data/athleteData';

interface ContactSectionProps {
  onOpenDeckModal: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenDeckModal }) => {
  const [formData, setFormData] = useState({
    sponsorName: 'Ramsports Team',
    contactPerson: '',
    email: '',
    phone: '',
    selectedTier: 'Tournament & Travel Title Partner',
    message: 'Halo Ravy Sultan, kami tertarik mendiskusikan peluang kolaborasi sponsorship apparel & paddle resmi untuk turnamen 2026.',
  });

  const [submitted, setSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(INITIAL_ATHLETE_PROFILE.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-[#0B0E14] text-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto pb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#D4FF00]/10 border border-[#D4FF00]/30 text-[#D4FF00] text-xs font-bold uppercase tracking-wider mb-3">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>RESPONS CEPAT & JALUR KOMUNIKASI RESMI</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black font-heading tracking-tight text-white uppercase">
            HUBUNGI ATLET & INISIASI KEMITRAAN
          </h2>

          <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed">
            Terbuka untuk diskusi proposal, pengujian paddle resmi, pertemuan tatap muka di area Jakarta/Jabodetabek, atau alignment program promosi digital.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mt-4">
          
          {/* Left Column: Direct Fast Channels */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* WhatsApp Priority Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-[#D4FF00]/15 via-white/[0.03] to-black/60 border border-[#D4FF00]/30 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#D4FF00] bg-[#D4FF00]/20 px-2 py-0.5 rounded">
                  DIREKOMENDASIKAN (RESPONS &lt; 2 JAM)
                </span>
                <span className="w-2.5 h-2.5 rounded-full bg-[#D4FF00] animate-ping" />
              </div>

              <h3 className="text-xl font-bold font-heading text-white mt-3">
                WhatsApp Direct Connect
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Langsung terhubung dengan atlet Ravy Sultan untuk koordinasi jadwal sparring, sampling paddle, atau meeting kemitraan.
              </p>

              <div className="mt-5">
                <a
                  href={`https://wa.me/${INITIAL_ATHLETE_PROFILE.whatsappNumber}?text=Halo%20Ravy%20Sultan,%20kami%20dari%20tim%20Ramsports%20tertarik%20membahas%20kemitraan%20sponsorship%20pickleball.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-4 rounded-xl bg-[#D4FF00] hover:bg-[#c2e800] text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#D4FF00]/20"
                >
                  <MessageSquare className="w-4 h-4 fill-black" />
                  <span>Chat WhatsApp Sekarang</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Email & Phone Details */}
            <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/10 space-y-4">
              
              {/* Email */}
              <div className="flex items-center justify-between text-xs pb-3 border-b border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-slate-300">
                    <Mail className="w-4 h-4 text-[#D4FF00]" />
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Email Resmi Atlet:</span>
                    <span className="font-semibold text-white">{INITIAL_ATHLETE_PROFILE.email}</span>
                  </div>
                </div>

                <button
                  onClick={handleCopyEmail}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                  title="Salin alamat email"
                >
                  {copiedEmail ? (
                    <span className="text-[10px] text-emerald-400 font-bold">Disalin!</span>
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              {/* Phone */}
              <div className="flex items-center gap-3 text-xs pb-3 border-b border-white/5">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-slate-300">
                  <Phone className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Nomor Telepon:</span>
                  <span className="font-semibold text-white">{INITIAL_ATHLETE_PROFILE.phone}</span>
                </div>
              </div>

              {/* Location */}
              <div className="flex items-center gap-3 text-xs">
                <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-slate-300">
                  <MapPin className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Lokasi Home Base:</span>
                  <span className="font-semibold text-white">{INITIAL_ATHLETE_PROFILE.location}</span>
                </div>
              </div>

            </div>

            {/* Deck Download Trigger */}
            <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/10 flex items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold text-white font-heading">
                  Proposal Kemitraan Digital
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Format ringkasan eksekutif untuk rapat manajemen brand Ramsports.
                </p>
              </div>

              <button
                onClick={onOpenDeckModal}
                className="shrink-0 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs flex items-center gap-2 border border-white/10 transition-colors"
              >
                <FileText className="w-4 h-4 text-[#D4FF00]" />
                <span>Buka Ringkasan Deck</span>
              </button>
            </div>

          </div>

          {/* Right Column: Interactive Proposal & Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-3xl bg-black/60 border border-white/10 shadow-2xl relative">
              
              <div className="pb-6 border-b border-white/10">
                <h3 className="text-2xl font-bold font-heading text-white">
                  Kirim Undangan / Brief Kemitraan
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Isi formulir berikut, data akan langsung diteruskan ke tim representasi atlet.
                </p>
              </div>

              {submitted ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#D4FF00]/20 border border-[#D4FF00] flex items-center justify-center mx-auto text-[#D4FF00]">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-xl font-bold text-white font-heading">
                    Pesan Kemitraan Berhasil Dikirim!
                  </h4>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    Terima kasih telah menghubungi Ravy Sultan. Kami akan meninjau rincian penawaran dari <strong className="text-white">{formData.sponsorName}</strong> dan merespons dalam waktu 1x24 jam.
                  </p>
                  <div className="pt-4">
                    <button
                      onClick={() => setSubmitted(false)}
                      className="px-6 py-2.5 rounded-xl bg-white/10 text-xs font-semibold text-white hover:bg-white/20"
                    >
                      Kirim Pesan Lain
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nama Brand / Perusahaan:
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.sponsorName}
                        onChange={(e) => setFormData({ ...formData, sponsorName: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4FF00]"
                        placeholder="Contoh: Ramsports Indonesia"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nama Narahubung / PIC:
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.contactPerson}
                        onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4FF00]"
                        placeholder="Nama lengkap Anda"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Alamat Email PIC:
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4FF00]"
                        placeholder="nama@ramsports.com"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nomor HP / WhatsApp:
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4FF00]"
                        placeholder="+62 8..."
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Pilihan Paket / Format Kerjasama:
                    </label>
                    <select
                      value={formData.selectedTier}
                      onChange={(e) => setFormData({ ...formData, selectedTier: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0E121A] border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4FF00]"
                    >
                      <option value="Official Equipment & Paddle Partner">Official Equipment & Paddle Partner</option>
                      <option value="Tournament & Travel Title Partner">Tournament & Travel Title Partner (Rekomendasi)</option>
                      <option value="Signature Brand Ambassador">Signature Brand Ambassador & Co-Branding</option>
                      <option value="Custom Collaboration / Exhibition">Custom Collaboration / Exhibition Match</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Catatan atau Pesan Tambahan:
                    </label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-[#D4FF00]"
                      placeholder="Tuliskan objektif atau detail kemitraan yang diharapkan..."
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl bg-[#D4FF00] hover:bg-[#c2e800] text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-[#D4FF00]/20 transition-all hover:scale-[1.01]"
                    >
                      <Send className="w-4 h-4 fill-black" />
                      <span>Kirim Undangan Kemitraan</span>
                    </button>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

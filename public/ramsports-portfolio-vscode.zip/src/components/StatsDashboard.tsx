import React, { useState } from 'react';
import { 
  Activity, 
  TrendingUp, 
  Zap, 
  ShieldAlert, 
  Target, 
  RefreshCw, 
  Sliders, 
  CheckCircle, 
  Flame, 
  Crosshair,
  BarChart3,
  Clock,
  Radio
} from 'lucide-react';
import { PerformanceStats, AthleteProfile } from '../types';

interface StatsDashboardProps {
  stats: PerformanceStats;
  profile: AthleteProfile;
  isApiLive: boolean;
  onToggleApiLive: () => void;
  onRefreshApi: () => void;
  onOpenApiModal: () => void;
}

export const StatsDashboard: React.FC<StatsDashboardProps> = ({
  stats,
  profile,
  isApiLive,
  onToggleApiLive,
  onRefreshApi,
  onOpenApiModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'court' | 'podiums'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    onRefreshApi();
    setTimeout(() => setIsRefreshing(false), 600);
  };

  return (
    <section id="stats" className="py-20 bg-[#0E121A] text-slate-100 relative border-t border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Live API Sync Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D4FF00] animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#D4FF00]">
                TELEMETRI & DATA STATISTIK PEMAIN
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black font-heading tracking-tight text-white">
              DASHBOARD PERFORMA ATLET REAL-TIME
            </h2>
            <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl">
              Metrik performa lapangan tervalidasi DUPR (Dynamic Universal Pickleball Rating) dan statistik turnamen resmi yang diperbarui secara dinamis via API integrasi.
            </p>
          </div>

          {/* Interactive API Sync Control Strip */}
          <div className="flex flex-wrap items-center gap-3 bg-black/40 p-2 rounded-xl border border-white/10">
            
            {/* Auto Live Toggle */}
            <button
              onClick={onToggleApiLive}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                isApiLive 
                  ? 'bg-[#D4FF00] text-black shadow-md shadow-[#D4FF00]/20' 
                  : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${isApiLive ? 'animate-pulse' : ''}`} />
              <span>{isApiLive ? 'Live Sync Active' : 'Live Sync Off'}</span>
            </button>

            {/* Manual Refresh Trigger */}
            <button
              onClick={handleManualRefresh}
              title="Tarik data terbaru dari API endpoint"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#D4FF00]' : 'text-slate-400'}`} />
              <span>Refresh API</span>
            </button>

            {/* Simulator / API Modal Trigger */}
            <button
              onClick={onOpenApiModal}
              title="Konfigurasi payload data API atau ubah statistik untuk demonstrasi"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#D4FF00]/10 hover:bg-[#D4FF00]/20 text-[#D4FF00] border border-[#D4FF00]/30 transition-colors"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Simulator API</span>
            </button>

            {/* Timestamp */}
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 px-2 py-1 bg-white/[0.03] rounded-md border border-white/5">
              <Clock className="w-3 h-3 text-slate-400" />
              <span className="font-mono text-[10px] text-slate-300">{stats.lastSyncTime}</span>
            </div>

          </div>
        </div>

        {/* Primary DUPR & Core Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          
          {/* Card 1: DUPR Rating */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.01] border border-white/10 relative overflow-hidden group hover:border-[#D4FF00]/50 transition-all">
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#D4FF00]/5 rounded-bl-full pointer-events-none" />
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold uppercase tracking-wider">Rating Resmi DUPR</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                Verified Pro Tier
              </span>
            </div>
            
            <div className="mt-4 flex items-baseline gap-3">
              <div className="text-4xl font-black font-heading text-white">
                {profile.duprDoubles}
              </div>
              <div className="text-xs font-bold text-[#D4FF00] bg-[#D4FF00]/10 px-2 py-0.5 rounded">
                Ganda Putra (MD)
              </div>
            </div>

            <div className="mt-2 flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-white/5">
              <span>Tunggal Putra (MS):</span>
              <span className="font-bold text-white font-mono">{profile.duprSingles}</span>
            </div>

            {/* Progress bar towards 5.5 Pro Benchmark */}
            <div className="mt-4">
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Pro Circuit Target</span>
                <span className="text-white font-semibold">93.4% of 5.5 Pro</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-lime-400 to-[#D4FF00] rounded-full transition-all duration-1000"
                  style={{ width: `${(profile.duprDoubles / 5.5) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Card 2: Win Rate & Matches */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.01] border border-white/10 relative overflow-hidden group hover:border-[#D4FF00]/50 transition-all">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold uppercase tracking-wider">Rasio Kemenangan</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4FF00]/20 text-[#D4FF00] font-mono">
                Streak: {stats.currentStreak} W
              </span>
            </div>

            <div className="mt-4 flex items-baseline gap-3">
              <div className="text-4xl font-black font-heading text-[#D4FF00]">
                {stats.winRate}%
              </div>
              <div className="text-xs font-bold text-slate-300">
                {stats.matchesWon}W - {stats.matchesPlayed - stats.matchesWon}L
              </div>
            </div>

            <p className="mt-2 text-xs text-slate-400">
              Berdasarkan 52 pertandingan kompetitif resmi di sirkuit turnamen Jakarta & regional.
            </p>

            <div className="mt-4">
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Efisiensi Match Point</span>
                <span className="text-white font-semibold">{stats.winRate}% Win</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-[#D4FF00] rounded-full transition-all duration-1000"
                  style={{ width: `${stats.winRate}%` }}
                />
              </div>
            </div>
          </div>

          {/* Card 3: Podium Conversion Rate */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.01] border border-white/10 relative overflow-hidden group hover:border-[#D4FF00]/50 transition-all">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold uppercase tracking-wider">Konversi Podium</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                7x Gelar
              </span>
            </div>

            <div className="mt-4 flex items-baseline gap-3">
              <div className="text-4xl font-black font-heading text-white">
                {((stats.podiumsTotal / stats.tournamentsCompeted) * 100).toFixed(1)}%
              </div>
              <div className="text-xs font-bold text-amber-400">
                {stats.podiumsTotal} dari {stats.tournamentsCompeted} Turnamen
              </div>
            </div>

            <div className="mt-3 flex items-center gap-2 text-xs text-slate-300">
              <span className="px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 font-bold text-[11px]">1 Gold</span>
              <span className="px-2 py-0.5 rounded bg-slate-300/20 text-slate-200 font-bold text-[11px]">4 Silver</span>
              <span className="px-2 py-0.5 rounded bg-amber-700/30 text-amber-500 font-bold text-[11px]">2 Bronze</span>
            </div>

            <div className="mt-4 pt-2 border-t border-white/5 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Konsistensi Masuk Semifinal:</span>
              <span className="text-emerald-400 font-bold">88.8%</span>
            </div>
          </div>

          {/* Card 4: Smash Power & Attacking Pace */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.01] border border-white/10 relative overflow-hidden group hover:border-[#D4FF00]/50 transition-all">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold uppercase tracking-wider">Kecepatan Serangan</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono">
                Radar Sensor
              </span>
            </div>

            <div className="mt-4 flex items-baseline gap-2">
              <div className="text-4xl font-black font-heading text-white">
                {stats.avgSmashSpeedKmh}
              </div>
              <div className="text-xs font-bold text-slate-400">
                km/jam
              </div>
            </div>

            <p className="mt-2 text-xs text-slate-400">
              Rata-rata kecepatan overhead smash dan drive forehand tercepat mencapai 104 km/jam.
            </p>

            <div className="mt-4 pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
              <span>Potensi dengan Paddle Ramsports:</span>
              <span className="text-[#D4FF00] font-bold">+12% Spin & Pop</span>
            </div>
          </div>

        </div>

        {/* Detailed Technical Court Metrics (Shot Matrix) */}
        <div className="mt-10 p-6 sm:p-8 rounded-2xl bg-black/40 border border-white/10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold font-heading text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-[#D4FF00]" />
                <span>Analisis Taktikal Lapangan (Shot Matrix)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Data presisi teknik permainan: kontrol bola di kitchen line, transisi bertahan ke menyerang, dan disiplin unforced error.
              </p>
            </div>

            <div className="text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Tolok ukur pemain kompetitif pro level 5.0+</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
            
            {/* Metric 1 */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-400 font-medium">Third-Shot Drop Accuracy</span>
                <span className="font-extrabold text-[#D4FF00] text-sm">{stats.thirdShotDropPct}%</span>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-[#D4FF00] rounded-full"
                  style={{ width: `${stats.thirdShotDropPct}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Kunci transisi dari baseline ke kitchen zone dengan arc lembut minim attackable bounce.
              </p>
            </div>

            {/* Metric 2 */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-400 font-medium">Speed-Up Attack Conversion</span>
                <span className="font-extrabold text-white text-sm">{stats.speedUpConversionPct}%</span>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-emerald-400 rounded-full"
                  style={{ width: `${stats.speedUpConversionPct}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Efektivitas saat melakukan serangan dadakan dari dinking battle ke titik tubuh lawan.
              </p>
            </div>

            {/* Metric 3 */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-400 font-medium">Dink Rally Endurance</span>
                <span className="font-extrabold text-[#D4FF00] text-sm">{stats.dinkRallyEndurancePct}%</span>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-[#D4FF00] rounded-full"
                  style={{ width: `${stats.dinkRallyEndurancePct}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Konsistensi pertahanan dink silang tanpa melakukan kesalahan netting pada rally 15+ shot.
              </p>
            </div>

            {/* Metric 4 */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-400 font-medium">Unforced Errors / Set</span>
                <span className="font-extrabold text-emerald-400 text-sm">{stats.unforcedErrorsAvg} avg</span>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-emerald-400 rounded-full"
                  style={{ width: '85%' }}
                />
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Rendahnya tingkat error sendiri membuktikan kedewasaan mental saat poin krusial.
              </p>
            </div>

          </div>
        </div>

        {/* Live Recent Match Ticker */}
        <div className="mt-6 p-4 rounded-xl bg-white/[0.02] border border-white/5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded bg-[#D4FF00]/10 border border-[#D4FF00]/30 text-[#D4FF00] text-xs font-bold uppercase tracking-wider">
              Laga Terakhir
            </span>
            <span className="text-xs text-slate-300">
              Final Kadispora Cup DKI: <strong className="text-white">Ravy Sultan vs Finalist (11-8, 11-6)</strong> — WIN 🥇
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-400">
            <span>Next Target: Indonesia National Pickleball Open 2026</span>
            <button
              onClick={onOpenApiModal}
              className="text-[#D4FF00] hover:underline font-medium text-xs"
            >
              Lihat Payload JSON &rarr;
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};

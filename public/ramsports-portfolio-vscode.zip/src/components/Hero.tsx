import React, { useState } from 'react';
import { 
  Trophy, 
  Flame, 
  ArrowRight, 
  Download, 
  ShieldCheck, 
  MapPin, 
  CheckCircle2, 
  Zap,
  Sparkles,
  Layers
} from 'lucide-react';
import { AthleteProfile, PerformanceStats } from '../types';
import { resolveMediaUrl } from '../utils/mediaStorage';

interface HeroProps {
  profile: AthleteProfile;
  stats: PerformanceStats;
  onOpenDeckModal: () => void;
  onOpenMediaModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  profile,
  stats,
  onOpenDeckModal,
  onOpenMediaModal,
}) => {
  const [activeMediaTab, setActiveMediaTab] = useState<'profile' | 'podium' | 'game'>('profile');

  const mediaTabs = [
    { id: 'profile' as const, label: 'Foto Profil', fileName: 'fotoprofil.jpg' },
    { id: 'podium' as const, label: 'Podium Juara', fileName: 'fotomenggunakanmedali.jpg' },
    { id: 'game' as const, label: 'Aksi Lapangan', fileName: 'foto in game.jpg' },
  ];

  const currentFileName = mediaTabs.find((t) => t.id === activeMediaTab)?.fileName || 'fotoprofil.jpg';
  const currentImageUrl = resolveMediaUrl(currentFileName);

  return (
    <section id="hero" className="relative min-h-[92vh] pt-28 pb-16 flex items-center overflow-hidden">
      {/* Background Graphic Elements */}
      <div className="absolute inset-0 bg-[#0B0E14] dark:bg-[#0B0E14] pointer-events-none">
        {/* Subtle athletic field lines & glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-[#D4FF00]/10 blur-[130px] rounded-full" />
        <div className="absolute -top-24 right-0 w-96 h-96 bg-emerald-500/5 blur-[100px] rounded-full" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293708_1px,transparent_1px),linear-gradient(to_bottom,#1f293708_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Partnership Proposal Pitch */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            
            {/* Top Brand Partnership Kicker */}
            <div className="flex items-center gap-2.5">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-[#D4FF00] animate-ping" />
                <span className="text-xs font-bold tracking-widest uppercase text-slate-300">
                  OFFICIAL SPONSORSHIP DECK 2026/2027
                </span>
              </div>
              <span className="text-xs font-semibold text-[#D4FF00] tracking-wide uppercase">
                TARGET: RAMSPORTS
              </span>
            </div>

            {/* Main Headline */}
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight leading-[1.08] text-white">
                BUILT TO COMPETE. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4FF00] via-lime-300 to-white">
                  POWERED FOR THE PODIUM.
                </span>
              </h1>
              <p className="mt-4 text-base sm:text-lg text-slate-300 font-normal leading-relaxed max-w-2xl">
                Portofolio kemitraan resmi <strong className="text-white font-semibold">{profile.name}</strong> untuk brand global <strong className="text-[#D4FF00] font-semibold">RAMSPORTS</strong>. Menggabungkan rekam jejak kemenangan turnamen konsisten, rating DUPR kompetitif, serta eksposur dinamis di kancah pickleball Indonesia.
              </p>
            </div>

            {/* Metric Highlights Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2">
              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 hover:border-[#D4FF00]/40 transition-colors">
                <span className="text-xs text-slate-400 block font-medium">Rating DUPR</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-extrabold text-white font-heading">{profile.duprDoubles}</span>
                  <span className="text-[11px] text-[#D4FF00] font-semibold">Doubles</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-0.5 block">{profile.duprSingles} Singles</span>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 hover:border-[#D4FF00]/40 transition-colors">
                <span className="text-xs text-slate-400 block font-medium">Rekor Podium</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-extrabold text-white font-heading">{stats.podiumsTotal}x</span>
                  <span className="text-[11px] text-amber-400 font-semibold">Gelar</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-0.5 block">1 Gold · 4 Silver · 2 Bronze</span>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 hover:border-[#D4FF00]/40 transition-colors">
                <span className="text-xs text-slate-400 block font-medium">Win Rate</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-extrabold text-[#D4FF00] font-heading">{stats.winRate}%</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-0.5 block">{stats.matchesWon} Menang / {stats.matchesPlayed} Laga</span>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 hover:border-[#D4FF00]/40 transition-colors">
                <span className="text-xs text-slate-400 block font-medium">Basis Domisili</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-base font-bold text-white font-heading truncate">Jakarta, ID</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-0.5 block">Jabodetabek circuit</span>
              </div>
            </div>

            {/* Action CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onOpenDeckModal}
                className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl font-bold text-sm uppercase tracking-wider bg-[#D4FF00] text-black hover:bg-[#c3ea00] transition-all transform hover:-translate-y-0.5 shadow-lg shadow-[#D4FF00]/25"
              >
                <span>Tinjau Proposal Sponsor</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={`https://wa.me/${profile.whatsappNumber}?text=Halo%20Ravy%20Sultan,%20kami%20dari%20tim%20Ramsports%20ingin%20berdiskusi%20kemitraan%20sponsorship.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3.5 rounded-xl font-semibold text-sm bg-white/5 hover:bg-white/10 text-white border border-white/10 hover:border-[#D4FF00]/40 transition-all"
              >
                <Zap className="w-4 h-4 text-[#D4FF00]" />
                <span>Hubungi via WhatsApp</span>
              </a>

              <a
                href="#tournaments"
                className="px-4 py-3.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
              >
                Lihat 7 Bukti Prestasi &rarr;
              </a>
            </div>

            {/* Brand alignment guarantee */}
            <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
              <ShieldCheck className="w-4 h-4 text-[#D4FF00] shrink-0" />
              <span>
                Siap mempromosikan line-up paddle & gear resmi <strong className="text-slate-200">Ramsports Global</strong> di seluruh sirkuit turnamen 2026/2027.
              </span>
            </div>

          </div>

          {/* Right Column: High-Impact Athlete Media Showcase */}
          <div className="lg:col-span-5 flex flex-col items-center">
            
            {/* Interactive Spotlight Card */}
            <div className="relative w-full max-w-md rounded-2xl overflow-hidden bg-gradient-to-b from-white/10 to-white/[0.02] p-1 border border-white/10 shadow-2xl">
              
              {/* Media Switcher Tab Header */}
              <div className="bg-[#0B0E14]/80 backdrop-blur-md p-1.5 rounded-t-xl flex items-center justify-between border-b border-white/10">
                <div className="flex items-center gap-1">
                  {mediaTabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveMediaTab(tab.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        activeMediaTab === tab.id
                          ? 'bg-[#D4FF00] text-black shadow-sm'
                          : 'text-slate-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                <button
                  onClick={onOpenMediaModal}
                  title="Ganti atau upload foto asli Anda"
                  className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-[#D4FF00] transition-colors text-xs flex items-center gap-1"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span className="text-[10px]">Kelola</span>
                </button>
              </div>

              {/* Main Image Frame */}
              <div className="relative aspect-[4/5] w-full bg-slate-950 overflow-hidden group">
                <img
                  src={currentImageUrl}
                  alt={profile.name}
                  className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    // Fallback in case of broken link
                    (e.currentTarget as HTMLImageElement).src =
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80';
                  }}
                />

                {/* Dark gradient overlay for typography readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E14] via-[#0B0E14]/30 to-transparent" />

                {/* Top Badge: Ramsports Brand Identity Badge */}
                <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-[#D4FF00]/40">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#D4FF00]" />
                  <span className="text-[11px] font-bold text-white tracking-wider uppercase">
                    RAMSPORTS AMBASSADOR PROSPECT
                  </span>
                </div>

                {/* File Name Tag indicator (referencing the user's specific file from screenshot) */}
                <div className="absolute top-4 right-4 px-2 py-0.5 rounded bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-mono text-slate-300">
                  {currentFileName}
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#0B0E14]/85 backdrop-blur-md border border-white/10 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-extrabold text-white font-heading tracking-wide">
                        {profile.name}
                      </h3>
                      <p className="text-xs text-slate-300">
                        {profile.discipline}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Podium Track</span>
                      <span className="text-sm font-extrabold text-[#D4FF00]">
                        7x Medals DKI & Reg.
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                    <span className="flex items-center gap-1 text-slate-300">
                      <MapPin className="w-3.5 h-3.5 text-[#D4FF00]" />
                      {profile.location}
                    </span>
                    <span className="font-semibold text-emerald-400">
                      Active Tour 2026
                    </span>
                  </div>
                </div>

              </div>

            </div>

            {/* Quick caption under photo */}
            <p className="mt-3 text-xs text-slate-400 text-center flex items-center gap-1.5">
              <span>Mencakup aset foto:</span>
              <code className="text-[#D4FF00] font-mono bg-white/5 px-1 py-0.5 rounded text-[11px]">
                {currentFileName}
              </code>
            </p>

          </div>

        </div>
      </div>
    </section>
  );
};

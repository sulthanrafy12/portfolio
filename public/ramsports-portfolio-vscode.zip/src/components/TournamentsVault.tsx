import React, { useState } from 'react';
import { 
  Trophy, 
  Medal, 
  Award, 
  Calendar, 
  MapPin, 
  ExternalLink, 
  Eye, 
  CheckCircle2, 
  Filter,
  Layers,
  Sparkles,
  X
} from 'lucide-react';
import { TOURNAMENT_RECORDS } from '../data/athleteData';
import { TournamentRecord } from '../types';
import { resolveMediaUrl } from '../utils/mediaStorage';

interface TournamentsVaultProps {
  onOpenMediaModal: () => void;
}

export const TournamentsVault: React.FC<TournamentsVaultProps> = ({ onOpenMediaModal }) => {
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [activeModalRecord, setActiveModalRecord] = useState<TournamentRecord | null>(null);

  const filteredTournaments = TOURNAMENT_RECORDS.filter((tour) => {
    if (selectedTier === 'all') return true;
    if (selectedTier === 'gold') return tour.tier === 'gold';
    if (selectedTier === 'silver') return tour.tier === 'silver';
    if (selectedTier === 'bronze') return tour.tier === 'bronze';
    if (selectedTier === 'doubles') return tour.category.includes('Doubles');
    if (selectedTier === 'singles') return tour.category.includes('Singles');
    return true;
  });

  return (
    <section id="tournaments" className="py-20 bg-[#0B0E14] text-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                KABINET PRESTASI & DOKUMEN RESMI
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black font-heading tracking-tight text-white">
              REKAM JEJAK PODIUM TURNAMEN
            </h2>
            <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl">
              Bukti otentik medali dan sertifikat kejuaraan resmi yang telah dicapai di sirkuit pickleball regional dan nasional.
            </p>
          </div>

          {/* Medals Summary Pill & Media Link */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs">
              <span className="text-amber-400 font-extrabold text-sm">1</span> Emas
              <span className="text-slate-500">·</span>
              <span className="text-slate-300 font-extrabold text-sm">4</span> Perak
              <span className="text-slate-500">·</span>
              <span className="text-amber-600 font-extrabold text-sm">2</span> Perunggu
            </div>

            <button
              onClick={onOpenMediaModal}
              className="text-xs text-[#D4FF00] hover:underline flex items-center gap-1 font-semibold"
            >
              <span>Kelola File Dokumen</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap items-center gap-2 mt-8">
          {[
            { id: 'all', label: 'Semua Prestasi (7)' },
            { id: 'gold', label: '🥇 Juara 1 / Emas' },
            { id: 'silver', label: '🥈 Juara 2 / Perak' },
            { id: 'bronze', label: '🥉 Juara 3 / Perunggu' },
            { id: 'doubles', label: 'Ganda Putra (Doubles)' },
            { id: 'singles', label: 'Tunggal Putra (Singles)' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedTier(tab.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedTier === tab.id
                  ? 'bg-[#D4FF00] text-black shadow-md shadow-[#D4FF00]/20'
                  : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tournament Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {filteredTournaments.map((tour) => {
            const imageUrl = resolveMediaUrl(tour.fileName);
            const isGold = tour.tier === 'gold';
            const isSilver = tour.tier === 'silver';
            const isBronze = tour.tier === 'bronze';

            return (
              <div
                key={tour.id}
                onClick={() => setActiveModalRecord(tour)}
                className={`group cursor-pointer rounded-2xl overflow-hidden bg-gradient-to-b from-white/[0.05] to-white/[0.01] border transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                  isGold
                    ? 'border-amber-400/40 hover:border-amber-400 shadow-amber-400/10'
                    : isSilver
                    ? 'border-slate-300/30 hover:border-slate-200 shadow-slate-300/10'
                    : 'border-amber-700/30 hover:border-amber-600 shadow-amber-700/10'
                }`}
              >
                {/* Image Preview Header */}
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-slate-950">
                  <img
                    src={imageUrl}
                    alt={tour.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=800&q=80';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E14] via-[#0B0E14]/40 to-transparent" />

                  {/* Achievement Medal Badge */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1 rounded-full backdrop-blur-md bg-black/70 border border-white/10">
                    <Medal
                      className={`w-4 h-4 ${
                        isGold ? 'text-amber-400' : isSilver ? 'text-slate-200' : 'text-amber-600'
                      }`}
                    />
                    <span
                      className={`text-xs font-black uppercase tracking-wider font-heading ${
                        isGold ? 'text-amber-400' : isSilver ? 'text-slate-100' : 'text-amber-400'
                      }`}
                    >
                      {tour.achievement}
                    </span>
                  </div>

                  {/* File Name Tag */}
                  <div className="absolute top-3 right-3 px-2 py-0.5 rounded bg-black/75 backdrop-blur-sm border border-white/10 text-[10px] font-mono text-slate-300 truncate max-w-[170px]">
                    {tour.fileName}
                  </div>

                  {/* Year & Category Pill */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-slate-300">
                    <span className="font-semibold text-white">{tour.category}</span>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#D4FF00]" />
                      {tour.year}
                    </span>
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-5 flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg font-bold font-heading text-white group-hover:text-[#D4FF00] transition-colors leading-snug">
                      {tour.title}
                    </h3>
                    <p className="mt-2 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {tour.notes}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                    <span className="text-slate-400 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {tour.location}
                    </span>
                    <span className="text-[#D4FF00] font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                      <span>Buka Bukti</span>
                      <Eye className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Feature Medals Banner (fotobeberapamedali.jpg & fotomenggunakanmedali.jpg showcase) */}
        <div className="mt-14 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900/40 to-[#0B0E14] border border-amber-500/20 p-6 sm:p-8 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center shrink-0">
              <Trophy className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h4 className="text-lg font-bold text-white font-heading">
                Konsistensi Juara: 7 Medali Resmi Terverifikasi
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                Dokumentasi lengkap medali fisik (<code className="text-[#D4FF00] text-xs">fotobeberapamedali.jpg</code>) dan selebrasi podium (<code className="text-[#D4FF00] text-xs">fotomenggunakanmedali.jpg</code>) siap disematkan pada materi promosi brand Ramsports.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenMediaModal}
            className="shrink-0 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white border border-white/10 text-xs font-semibold flex items-center gap-2 transition-all hover:border-[#D4FF00]/50"
          >
            <Layers className="w-4 h-4 text-[#D4FF00]" />
            <span>Lihat Galeri Medali & File</span>
          </button>
        </div>

      </div>

      {/* Single Tournament Detail Modal */}
      {activeModalRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-2xl bg-[#0E121A] border border-white/20 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-2">
                <Medal className="w-5 h-5 text-amber-400" />
                <span className="text-sm font-bold text-white font-heading uppercase">
                  Bukti Otentik Prestasi
                </span>
              </div>
              <button
                onClick={() => setActiveModalRecord(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Image Box */}
            <div className="relative aspect-[16/10] bg-black overflow-hidden flex items-center justify-center">
              <img
                src={resolveMediaUrl(activeModalRecord.fileName)}
                alt={activeModalRecord.title}
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=900&q=80';
                }}
              />
              <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded bg-black/80 text-[11px] font-mono text-[#D4FF00] border border-[#D4FF00]/30">
                File: {activeModalRecord.fileName}
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
                  <span>{activeModalRecord.achievement}</span>
                  <span>·</span>
                  <span>{activeModalRecord.category}</span>
                </div>
                <h3 className="text-xl font-extrabold text-white font-heading">
                  {activeModalRecord.title}
                </h3>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {activeModalRecord.notes}
              </p>

              {activeModalRecord.statsHighlight && (
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs">
                  <span className="font-semibold text-[#D4FF00] block mb-0.5">Statistik Laga Kunci:</span>
                  <span className="text-slate-300">{activeModalRecord.statsHighlight}</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-white/10 text-slate-400">
                <div>
                  <span className="block text-slate-500">Lokasi Penyelenggaraan:</span>
                  <span className="font-semibold text-white">{activeModalRecord.location}</span>
                </div>
                <div>
                  <span className="block text-slate-500">Tahun Kejuaraan:</span>
                  <span className="font-semibold text-white">{activeModalRecord.year}</span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  onClick={() => setActiveModalRecord(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Tutup
                </button>
                <a
                  href={`https://wa.me/6281288992345?text=Halo%20Ravy,%20kami%20tertarik%20dengan%20prestasi%20di%20${encodeURIComponent(activeModalRecord.title)}.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-lg text-xs font-bold bg-[#D4FF00] text-black hover:bg-[#c1e700]"
                >
                  Ajukan Pertanyaan ke Atlet
                </a>
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};

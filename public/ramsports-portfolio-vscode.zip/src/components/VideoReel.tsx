import React, { useState, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Flame, 
  Sparkles, 
  Zap, 
  Video, 
  Layers,
  CheckCircle2
} from 'lucide-react';
import { resolveMediaUrl } from '../utils/mediaStorage';

interface VideoReelProps {
  onOpenMediaModal: () => void;
}

export const VideoReel: React.FC<VideoReelProps> = ({ onOpenMediaModal }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [activeTimestamp, setActiveTimestamp] = useState<string>('0:14');
  const videoRef = useRef<HTMLVideoElement>(null);

  const videoUrl = resolveMediaUrl('videosatu.mp4');

  const timestamps = [
    { time: '0:14', label: 'ATP (Around-The-Post) Winner', desc: 'Penempatan bola lengkung melewati jaring dari sudut sempit' },
    { time: '0:38', label: 'Fast-Hands Kitchen Dink Duel', desc: 'Kecepatan reaksi tangan saat rally dinking 14-shot intens' },
    { time: '1:02', label: 'Overhead Smash Match Point', desc: 'Penyelesaian poin pamungkas dengan smash eksplosif' },
  ];

  const handlePlayToggle = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {
        // Autoplay may be restricted
      });
    }
  };

  const handleMuteToggle = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleSeek = (timeStr: string) => {
    setActiveTimestamp(timeStr);
    if (!videoRef.current) return;
    const parts = timeStr.split(':');
    const seconds = parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
    videoRef.current.currentTime = seconds;
    if (!isPlaying) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <section id="video" className="py-20 bg-[#0B0E14] text-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Video className="w-4 h-4 text-[#D4FF00]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#D4FF00]">
                GAMEPLAY REEL & HIGHLIGHT
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black font-heading tracking-tight text-white">
              CUPLIKAN PERTANDINGAN NYATA
            </h2>
            <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl">
              Aksi langsung di lapangan turnamen menunjukkan intensitas permainan, refleks cepat, dan penempatan bola taktis.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400 font-mono bg-white/5 px-2.5 py-1 rounded border border-white/10">
              videosatu.mp4
            </span>
            <button
              onClick={onOpenMediaModal}
              className="text-xs text-[#D4FF00] hover:underline flex items-center gap-1 font-semibold"
            >
              <span>Ganti File Video</span>
            </button>
          </div>
        </div>

        {/* Video Player & Timestamp Highlights */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-8 items-start">
          
          {/* Main Video Frame (Col 8) */}
          <div className="lg:col-span-8 rounded-2xl overflow-hidden bg-black border border-white/10 shadow-2xl relative group">
            
            <div className="relative aspect-video w-full bg-zinc-950 flex items-center justify-center">
              <video
                ref={videoRef}
                src={videoUrl}
                muted={isMuted}
                loop
                playsInline
                className="w-full h-full object-cover"
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                poster="https://images.unsplash.com/photo-1554068865-24cecd4e34b8?auto=format&fit=crop&w=1200&q=80"
              />

              {/* Play overlay button if paused */}
              {!isPlaying && (
                <button
                  onClick={handlePlayToggle}
                  className="absolute z-10 w-20 h-20 rounded-full bg-[#D4FF00] text-black flex items-center justify-center shadow-xl shadow-[#D4FF00]/30 hover:scale-110 transition-transform"
                >
                  <Play className="w-8 h-8 fill-black translate-x-0.5" />
                </button>
              )}

              {/* Floating watermark / brand tag */}
              <div className="absolute top-4 left-4 z-10 flex items-center gap-2 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-xs">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="font-bold text-white uppercase text-[11px]">MATCH REPLAY · 60 FPS</span>
              </div>

              {/* Controls bar on hover */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-between z-10 opacity-90 group-hover:opacity-100 transition-opacity">
                <div className="flex items-center gap-3">
                  <button
                    onClick={handlePlayToggle}
                    className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={handleMuteToggle}
                    className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>

                  <span className="text-xs text-slate-300 font-mono">
                    Cuplikan: {activeTimestamp}
                  </span>
                </div>

                <div className="text-xs text-slate-400 font-medium">
                  Ramsports Ready Action
                </div>
              </div>
            </div>

          </div>

          {/* Interactive Moments Selector & Key Skills (Col 4) */}
          <div className="lg:col-span-4 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">
              Pilih Timestamp Sorotan:
            </h3>

            {timestamps.map((item) => (
              <div
                key={item.time}
                onClick={() => handleSeek(item.time)}
                className={`p-4 rounded-xl cursor-pointer transition-all border ${
                  activeTimestamp === item.time
                    ? 'bg-[#D4FF00]/10 border-[#D4FF00] shadow-md'
                    : 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-black/60 text-[#D4FF00]">
                    {item.time}
                  </span>
                  <span className="text-[11px] text-slate-400 font-semibold">KLIK UNTUK PUTAR</span>
                </div>
                <h4 className="text-sm font-bold text-white mt-2">
                  {item.label}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-snug">
                  {item.desc}
                </p>
              </div>
            ))}

            {/* Tactical Strengths Checklist */}
            <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2 mt-4">
              <span className="text-xs font-bold uppercase text-slate-300 block">
                Karakteristik Gaya Main:
              </span>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4FF00]" />
                <span>Aggressive Kitchen Counter & Dinking Control</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4FF00]" />
                <span>High-Spin Roll Volley & Reset Defence</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4FF00]" />
                <span>Clutch Point Focus di Game Penentuan</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { 
  Images, 
  UploadCloud, 
  ExternalLink, 
  Instagram, 
  Eye, 
  CheckCircle, 
  Share2, 
  Sparkles,
  Layers,
  X
} from 'lucide-react';
import { MEDIA_COLLECTION, SOCIAL_STATS, INITIAL_ATHLETE_PROFILE } from '../data/athleteData';
import { MediaItem } from '../types';
import { resolveMediaUrl } from '../utils/mediaStorage';

interface MediaGalleryProps {
  onOpenMediaModal: () => void;
}

export const MediaGallery: React.FC<MediaGalleryProps> = ({ onOpenMediaModal }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);

  const filteredItems = MEDIA_COLLECTION.filter((item) => {
    if (selectedCategory === 'all') return true;
    if (selectedCategory === 'trophy') return item.category === 'trophy';
    if (selectedCategory === 'action') return item.category === 'action' || item.category === 'profile';
    if (selectedCategory === 'social') return item.category === 'social';
    if (selectedCategory === 'gear') return item.category === 'gear';
    return true;
  });

  return (
    <section id="media" className="py-20 bg-[#0E121A] text-slate-100 relative border-t border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Images className="w-4 h-4 text-[#D4FF00]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#D4FF00]">
                VAULT FILE & ARSIP DOKUMENTASI
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black font-heading tracking-tight text-white">
              GALERI LENGKAP ASET ATLET (15 FILE)
            </h2>
            <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl">
              Kompilasi lengkap seluruh file foto aksi, medali, sertifikat, gear, rekaman video, serta analitik jangkauan sosial media.
            </p>
          </div>

          <button
            onClick={onOpenMediaModal}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4FF00] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#c2e800] transition-transform hover:scale-105 shadow-md shadow-[#D4FF00]/20"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload File Anda</span>
          </button>
        </div>

        {/* Social Reach Special Feature Cards (my instagram.png & mytiktok.png) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          {SOCIAL_STATS.map((social) => {
            const isInstagram = social.platform === 'Instagram';
            const socialImgUrl = resolveMediaUrl(social.fileName);

            return (
              <div
                key={social.platform}
                className="p-6 rounded-2xl bg-gradient-to-br from-white/[0.04] to-black/50 border border-white/10 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white ${
                          isInstagram
                            ? 'bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600'
                            : 'bg-black border border-white/20'
                        }`}
                      >
                        {isInstagram ? <Instagram className="w-5 h-5" /> : 'TT'}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">
                          {social.platform} Official
                        </h4>
                        <span className="text-xs text-slate-400 font-mono">
                          {social.handle}
                        </span>
                      </div>
                    </div>

                    <span className="text-[11px] font-mono text-[#D4FF00] bg-[#D4FF00]/10 px-2 py-0.5 rounded border border-[#D4FF00]/20">
                      File: {social.fileName}
                    </span>
                  </div>

                  {/* Metrics Row */}
                  <div className="grid grid-cols-3 gap-3 mt-4 text-center">
                    <div className="p-2.5 rounded-xl bg-white/[0.02]">
                      <span className="text-[10px] text-slate-400 uppercase block">Followers</span>
                      <span className="text-lg font-black text-white font-heading">{social.followers}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.02]">
                      <span className="text-[10px] text-slate-400 uppercase block">Monthly Reach</span>
                      <span className="text-lg font-black text-[#D4FF00] font-heading">{social.monthlyReach}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white/[0.02]">
                      <span className="text-[10px] text-slate-400 uppercase block">Engage Rate</span>
                      <span className="text-lg font-black text-emerald-400 font-heading">{social.engagementRate}</span>
                    </div>
                  </div>

                  <p className="mt-3 text-xs text-slate-400">
                    <strong className="text-slate-200">Karakteristik Audiens:</strong> {social.primaryAudience}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Tangkapan layar otentik analitik</span>
                  <button
                    onClick={() => {
                      const item = MEDIA_COLLECTION.find((m) => m.fileName === social.fileName);
                      if (item) setSelectedItem(item);
                    }}
                    className="text-[#D4FF00] hover:underline flex items-center gap-1 font-semibold"
                  >
                    <span>Perbesar Gambar</span>
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Filter categories */}
        <div className="flex flex-wrap items-center gap-2 mt-10">
          {[
            { id: 'all', label: 'Semua 15 File' },
            { id: 'trophy', label: 'Prestasi & Medali (9 File)' },
            { id: 'action', label: 'Foto Profil & Aksi (3 File)' },
            { id: 'gear', label: 'Peralatan Paddle (1 File)' },
            { id: 'social', label: 'Insight Media Sosial (2 File)' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#D4FF00] text-black shadow-md shadow-[#D4FF00]/20'
                  : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Media Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">
          {filteredItems.map((item) => {
            const itemUrl = resolveMediaUrl(item.fileName);
            const isVideo = item.category === 'video';

            return (
              <div
                key={item.fileName}
                onClick={() => setSelectedItem(item)}
                className="group relative cursor-pointer rounded-xl overflow-hidden bg-zinc-950 border border-white/10 hover:border-[#D4FF00]/50 transition-all duration-300 hover:-translate-y-1 shadow-lg"
              >
                <div className="relative aspect-square w-full overflow-hidden bg-slate-900">
                  <img
                    src={itemUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = item.highResStockFallback;
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                  {/* Category Pill */}
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[9px] font-bold text-white uppercase tracking-wider border border-white/10">
                    {item.category}
                  </div>

                  {isVideo && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="w-10 h-10 rounded-full bg-[#D4FF00] text-black flex items-center justify-center shadow-lg">
                        ▶
                      </span>
                    </div>
                  )}

                  {/* Bottom Filename */}
                  <div className="absolute bottom-2 left-2 right-2">
                    <span className="block text-[11px] font-mono text-[#D4FF00] truncate">
                      {item.fileName}
                    </span>
                    <span className="block text-[10px] text-slate-300 truncate">
                      {item.title}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Sync Local Files Help Tip */}
        <div className="mt-8 p-4 rounded-xl bg-white/[0.02] border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#D4FF00] shrink-0" />
            <span>
              Ingin menautkan langsung seluruh 15 foto asli dari komputermu? Gunakan <strong>File Manager</strong> untuk memilih atau drag & drop file-filenya sekaligus.
            </span>
          </div>
          <button
            onClick={onOpenMediaModal}
            className="shrink-0 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold transition-colors"
          >
            Buka File Manager &rarr;
          </button>
        </div>

      </div>

      {/* Lightbox / Modal for single media item */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-3xl bg-[#0E121A] border border-white/20 rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-2 truncate">
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#D4FF00]/10 text-[#D4FF00] border border-[#D4FF00]/30">
                  {selectedItem.fileName}
                </span>
                <span className="text-sm font-bold text-white truncate">
                  {selectedItem.title}
                </span>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative max-h-[60vh] bg-black flex items-center justify-center overflow-hidden">
              <img
                src={resolveMediaUrl(selectedItem.fileName)}
                alt={selectedItem.title}
                className="max-h-[60vh] w-auto object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = selectedItem.highResStockFallback;
                }}
              />
            </div>

            <div className="p-6 overflow-y-auto">
              <p className="text-sm text-slate-300 leading-relaxed">
                {selectedItem.description}
              </p>
              
              <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  Kategori Aset: <strong className="text-slate-300 capitalize">{selectedItem.category}</strong>
                </span>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="px-4 py-2 rounded-lg text-xs font-bold bg-[#D4FF00] text-black hover:bg-[#c2e800]"
                >
                  Selesai
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};

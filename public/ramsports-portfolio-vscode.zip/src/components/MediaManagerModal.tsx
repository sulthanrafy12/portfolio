import React, { useState } from 'react';
import { 
  X, 
  UploadCloud, 
  Check, 
  FileText, 
  Image as ImageIcon, 
  Video, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { MEDIA_COLLECTION } from '../data/athleteData';
import { saveMediaUrl, clearCustomMedia, getStoredMediaUrl, resolveMediaUrl } from '../utils/mediaStorage';

interface MediaManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMediaChanged: () => void;
}

export const MediaManagerModal: React.FC<MediaManagerModalProps> = ({
  isOpen,
  onClose,
  onMediaChanged,
}) => {
  const [notification, setNotification] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (fileName: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        saveMediaUrl(fileName, result);
        setNotification(`Berhasil memperbarui: ${fileName}`);
        onMediaChanged();
        setTimeout(() => setNotification(null), 3000);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleBulkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    let matchedCount = 0;
    Array.from(files).forEach((file) => {
      // Find matching item by filename
      const matched = MEDIA_COLLECTION.find(
        (m) => m.fileName.toLowerCase() === file.name.toLowerCase()
      );

      if (matched) {
        matchedCount++;
        const reader = new FileReader();
        reader.onload = (event) => {
          const result = event.target?.result as string;
          if (result) {
            saveMediaUrl(matched.fileName, result);
            onMediaChanged();
          }
        };
        reader.readAsDataURL(file);
      }
    });

    setNotification(`Berhasil menyinkronkan ${matchedCount} file yang sesuai nama!`);
    setTimeout(() => setNotification(null), 3500);
  };

  const [isZipping, setIsZipping] = useState(false);

  const handleDownloadAllZip = async () => {
    try {
      setIsZipping(true);
      setNotification('Sedang mengompres semua 15 file ke dalam 1 folder ZIP...');
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      const folder = zip.folder('aset_portofolio_ramsports');

      for (const item of MEDIA_COLLECTION) {
        const url = resolveMediaUrl(item.fileName);
        try {
          const res = await fetch(url);
          const blob = await res.blob();
          folder?.file(item.fileName, blob);
        } catch (err) {
          console.warn('Gagal menambahkan ke zip:', item.fileName, err);
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const downloadLink = document.createElement('a');
      downloadLink.href = URL.createObjectURL(content);
      downloadLink.download = 'folder_aset_ramsports_atlet.zip';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      setNotification('Folder ZIP berhasil diunduh ke komputer Anda!');
      setTimeout(() => setNotification(null), 3500);
    } catch (err) {
      console.error(err);
      setNotification('Gagal membuat ZIP. Pastikan koneksi stabil.');
    } finally {
      setIsZipping(false);
    }
  };

  const handleResetAll = () => {
    if (confirm('Kembalikan semua aset foto ke visual default atlet?')) {
      clearCustomMedia();
      onMediaChanged();
      setNotification('Semua aset telah direset ke visual default.');
      setTimeout(() => setNotification(null), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl bg-[#0E121A] border border-white/20 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div>
            <div className="flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-[#D4FF00]" />
              <h3 className="text-xl font-bold font-heading text-white">
                Folder Aset & File Manager (15 File Tersimpan)
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Lokasi folder server: <code className="text-[#D4FF00] font-mono bg-white/5 px-2 py-0.5 rounded">/public/assets/</code> (15 file tersimpan lengkap).
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notification Toast */}
        {notification && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-[#D4FF00]/15 border border-[#D4FF00]/40 text-[#D4FF00] text-xs font-semibold flex items-center justify-between">
            <span>{notification}</span>
            <Check className="w-4 h-4" />
          </div>
        )}

        {/* Bulk Drop, Download ZIP & Reset Toolbar */}
        <div className="p-6 pb-2">
          <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-[#D4FF00]" />
              <div>
                <span className="text-xs font-bold text-white block">
                  Folder Tersinkronisasi (/public/assets)
                </span>
                <span className="text-[11px] text-slate-400">
                  Anda bisa mengunduh 1 folder penuh berisi seluruh 15 file sekaligus, atau mengunggah file baru dari PC.
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
              <button
                onClick={handleDownloadAllZip}
                disabled={isZipping}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1.5 transition-all border border-white/10"
              >
                <span>{isZipping ? 'Mengompres...' : 'Unduh Folder ZIP'}</span>
              </button>

              <label className="cursor-pointer px-3.5 py-2 rounded-xl bg-[#D4FF00] hover:bg-[#c2e800] text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all">
                <UploadCloud className="w-4 h-4" />
                <span>Upload File</span>
                <input
                  type="file"
                  multiple
                  onChange={handleBulkUpload}
                  className="hidden"
                />
              </label>

              <button
                onClick={handleResetAll}
                title="Reset ke visual default"
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Assets List Table */}
        <div className="p-6 overflow-y-auto space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {MEDIA_COLLECTION.map((item) => {
              const customStored = getStoredMediaUrl(item.fileName);
              const isVideo = item.category === 'video';
              const resolvedUrl = resolveMediaUrl(item.fileName);

              return (
                <div
                  key={item.fileName}
                  className="p-3.5 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between gap-3 hover:border-white/20 transition-colors"
                >
                  {/* Thumbnail */}
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-black shrink-0 relative border border-white/10">
                    <img
                      src={resolvedUrl}
                      alt={item.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = item.highResStockFallback;
                      }}
                    />
                    {isVideo && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Video className="w-3 h-3 text-[#D4FF00]" />
                      </div>
                    )}
                  </div>

                  {/* Meta */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-mono font-semibold text-white truncate">
                        {item.fileName}
                      </span>
                      {customStored ? (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                          Custom
                        </span>
                      ) : (
                        <span className="text-[9px] font-medium px-1.5 py-0.2 rounded bg-white/5 text-slate-400">
                          Active
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 block truncate">
                      {item.title}
                    </span>
                  </div>

                  {/* Upload action button */}
                  <label className="cursor-pointer shrink-0 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-[11px] font-semibold flex items-center gap-1.5 transition-colors">
                    <UploadCloud className="w-3 h-3 text-[#D4FF00]" />
                    <span>Upload</span>
                    <input
                      type="file"
                      accept={isVideo ? 'video/*' : 'image/*'}
                      onChange={(e) => handleFileUpload(item.fileName, e)}
                      className="hidden"
                    />
                  </label>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-black/40 flex items-center justify-between text-xs text-slate-400">
          <span>File tersimpan lokal di browser secara aman (LocalStorage/Cache).</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#D4FF00] text-black font-bold hover:bg-[#c2e800] transition-colors"
          >
            Selesai & Terapkan
          </button>
        </div>

      </div>
    </div>
  );
};

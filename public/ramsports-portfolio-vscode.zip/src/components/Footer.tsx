import React from 'react';
import { ArrowUp, Instagram, ExternalLink, Heart } from 'lucide-react';
import { INITIAL_ATHLETE_PROFILE, RAMSPORTS_BRAND_INFO } from '../data/athleteData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#07090D] border-t border-white/10 text-slate-400 text-xs py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-white/5">
          
          {/* Brand Col */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#D4FF00] flex items-center justify-center font-extrabold text-black text-sm">
                R
              </div>
              <span className="font-extrabold font-heading text-white text-base tracking-wider uppercase">
                RAMSPORTS x RAVY SULTAN
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Official Athlete Sponsorship & Brand Ambassadorship Portfolio. Dibangun khusus untuk mempresentasikan sinergi prestasi atlet pickleball Indonesia bersama brand global Ramsports.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <span className="text-white font-bold uppercase tracking-wider block text-[11px]">
              Navigasi Halaman
            </span>
            <ul className="space-y-1.5">
              <li><a href="#hero" className="hover:text-[#D4FF00] transition-colors">Ikhtisar & Proposal</a></li>
              <li><a href="#stats" className="hover:text-[#D4FF00] transition-colors">Dashboard Statistik Real-Time</a></li>
              <li><a href="#tournaments" className="hover:text-[#D4FF00] transition-colors">Rekam Prestasi (7 Turnamen)</a></li>
              <li><a href="#synergy" className="hover:text-[#D4FF00] transition-colors">Sinergi Brand & ROI</a></li>
              <li><a href="#video" className="hover:text-[#D4FF00] transition-colors">Highlight Pertandingan</a></li>
              <li><a href="#media" className="hover:text-[#D4FF00] transition-colors">Vault 15 File & Dokumen</a></li>
            </ul>
          </div>

          {/* Target Brand & Social */}
          <div className="space-y-2">
            <span className="text-white font-bold uppercase tracking-wider block text-[11px]">
              Tautan Eksternal
            </span>
            <ul className="space-y-1.5">
              <li>
                <a 
                  href="https://www.instagram.com/ramsportspickleball/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-[#D4FF00] flex items-center gap-1 transition-colors"
                >
                  <span>@ramsportspickleball (Instagram)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a 
                  href="https://ramsports.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-[#D4FF00] flex items-center gap-1 transition-colors"
                >
                  <span>ramsports.com (Official Store)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a 
                  href={`https://wa.me/${INITIAL_ATHLETE_PROFILE.whatsappNumber}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#D4FF00] hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>WhatsApp Atlet: {INITIAL_ATHLETE_PROFILE.phone}</span>
                </a>
              </li>
            </ul>
          </div>

        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-400 text-center sm:text-left">
            &copy; {new Date().getFullYear()} Ravy Sultan · DUPR Verified Pickleball Athlete · Ramsports Partnership Presentation.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
          >
            <span>Kembali ke Atas</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Activity, 
  Sparkles, 
  Video, 
  Images, 
  Mail, 
  Sun, 
  Moon, 
  Radio, 
  UploadCloud, 
  Menu, 
  X,
  ExternalLink
} from 'lucide-react';
import { INITIAL_ATHLETE_PROFILE } from '../data/athleteData';

interface NavbarProps {
  darkMode: boolean;
  onToggleTheme: () => void;
  onOpenMediaModal: () => void;
  onOpenApiModal: () => void;
  isApiLive: boolean;
  onToggleApiLive: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  darkMode,
  onToggleTheme,
  onOpenMediaModal,
  onOpenApiModal,
  isApiLive,
  onToggleApiLive,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Ikhtisar', href: '#hero' },
    { name: 'Statistik', href: '#stats' },
    { name: 'Turnamen', href: '#tournaments' },
    { name: 'Sinergi Brand', href: '#synergy' },
    { name: 'Highlight', href: '#video' },
    { name: 'Media Vault', href: '#media' },
    { name: 'Kontak', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#0B0E14]/90 dark:bg-[#0B0E14]/90 backdrop-blur-md border-b border-white/10 shadow-xl'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo Synergy */}
          <a href="#hero" className="flex items-center gap-3 group">
            {/* Ramsports Circle Logo recreation */}
            <div className="w-10 h-10 rounded-full bg-[#D4FF00] flex items-center justify-center shadow-lg shadow-[#D4FF00]/20 transition-transform group-hover:scale-105">
              <span className="font-extrabold text-black text-xl tracking-tighter">R</span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-wider uppercase font-heading text-white dark:text-white">
                  RAMSPORTS
                </span>
                <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-white/10 text-[#D4FF00]">
                  PARTNER
                </span>
              </div>
              <span className="text-xs text-slate-400 font-medium">
                {INITIAL_ATHLETE_PROFILE.name} · Pickleball
              </span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-slate-300 hover:text-[#D4FF00] transition-colors relative py-1 hover:border-b-2 hover:border-[#D4FF00]"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Right Controls */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Live API indicator badge */}
            <button
              onClick={onOpenApiModal}
              title="Status API Real-time data pemain (Klik untuk buka simulasi)"
              className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 transition-all hover:border-[#D4FF00]/40"
            >
              <span className={`w-2 h-2 rounded-full ${isApiLive ? 'bg-[#D4FF00] animate-pulse' : 'bg-slate-500'}`} />
              <span>{isApiLive ? 'API LIVE' : 'API PAUSED'}</span>
              <span className="text-[10px] text-slate-400 bg-black/40 px-1 rounded">REST</span>
            </button>

            {/* Media Manager upload shortcut */}
            <button
              onClick={onOpenMediaModal}
              title="Kelola & upload foto-foto lokal atlet"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 transition-all"
            >
              <UploadCloud className="w-3.5 h-3.5 text-[#D4FF00]" />
              <span>File Manager (15)</span>
            </button>

            {/* Dark / Light Mode Toggle */}
            <button
              onClick={onToggleTheme}
              aria-label="Ganti mode tampilan"
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-300" />}
            </button>

            {/* Direct Connect WhatsApp CTA */}
            <a
              href={`https://wa.me/${INITIAL_ATHLETE_PROFILE.whatsappNumber}?text=Halo%20Ravy%20Sultan,%20kami%20dari%20tim%20Ramsports%20tertarik%20membahas%20kemitraan%20sponsorship%20pickleball.`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider bg-[#D4FF00] text-black hover:bg-[#c4ec00] transition-transform hover:scale-105 shadow-md shadow-[#D4FF00]/20"
            >
              <span>Hubungi Atlet</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile hamburger */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-lg bg-white/5 text-slate-300"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-white/5 text-slate-200"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        {mobileMenuOpen && (
          <div className="sm:hidden py-4 px-3 bg-[#0B0E14] border-b border-white/10 rounded-b-2xl shadow-2xl flex flex-col gap-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-white/5 hover:text-[#D4FF00]"
              >
                {link.name}
              </a>
            ))}
            <div className="pt-2 border-t border-white/10 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenApiModal();
                }}
                className="flex items-center justify-between px-3 py-2 rounded-lg bg-white/5 text-xs text-slate-300"
              >
                <span>Live API Simulator</span>
                <span className="w-2 h-2 rounded-full bg-[#D4FF00]" />
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenMediaModal();
                }}
                className="flex items-center justify-between px-3 py-2 rounded-lg bg-white/5 text-xs text-slate-300"
              >
                <span>File & Foto Vault (15 File)</span>
                <UploadCloud className="w-4 h-4 text-[#D4FF00]" />
              </button>
              <a
                href={`https://wa.me/${INITIAL_ATHLETE_PROFILE.whatsappNumber}?text=Halo%20Ravy%20Sultan,%20kami%20dari%20tim%20Ramsports%20tertarik%20membahas%20kemitraan%20sponsorship%20pickleball.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-center py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider bg-[#D4FF00] text-black"
              >
                Hubungi via WhatsApp
              </a>
            </div>
          </div>
        )}

      </div>
    </header>
  );
};
